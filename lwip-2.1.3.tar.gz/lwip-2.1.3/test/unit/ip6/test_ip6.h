#ifndef LWIP_HDR_TEST_IP6_H
#define LWIP_HDR_TEST_IP6_H

#include "../lwip_check.h"

Suite* ip6_suite(void);

#endif
